#include <iostream>
#include <stdexcept>

using namespace std;

// Custom exception class derived from std::exception
class CustomException : public exception
{
public:
    // Overriding the what() method from std::exception
    const char* what() const noexcept override
    {
        return "CustomException occurred";
    }
};

bool do_even_more_custom_application_logic()
{
    // Throwing a standard exception
    throw runtime_error("Standard exception thrown");

    return true;
}

void do_custom_application_logic()
{
    // Wrapping the call to do_even_more_custom_application_logic()
    // with an exception handler that catches std::exception, displays
    // a message and the exception.what(), then continues processing
    try
    {
        do_even_more_custom_application_logic();
    }
    catch (const exception& e)
    {
        cerr << "Caught exception: " << e.what() << endl;
    }

    // Throwing a custom exception derived from std::exception
    throw CustomException();
}

float divide(float num, float den)
{
    // Throw an exception to deal with divide by zero errors using
    // a standard C++ defined exception
    if (den == 0)
        throw invalid_argument("Denominator cannot be zero");

    return (num / den);
}

void do_division() noexcept
{
    float numerator = 10.0f;
    float denominator = 0;

    // Creating an exception handler to capture ONLY the exception thrown by divide.
    try
    {
        auto result = divide(numerator, denominator);
        cout << "divide(" << numerator << ", " << denominator << ") = " << result << endl;
    }
    catch (const invalid_argument& e)
    {
        cerr << "Caught exception: " << e.what() << endl;
    }
}

int main()
{
    try
    {
        // Create exception handlers that catch (in this order):
        //  your custom exception
        //  std::exception
        //  uncaught exception 
        //  that wraps the whole main function, and displays a message to the console.
        do_division();
        do_custom_application_logic();
    }
    catch (const CustomException& e)
    {
        cerr << "Caught custom exception: " << e.what() << endl;
    }
    catch (const exception& e)
    {
        cerr << "Caught standard exception: " << e.what() << endl;
    }
    catch (...)
    {
        cerr << "Caught unhandled exception." << endl;
    }

    return 0;
}
